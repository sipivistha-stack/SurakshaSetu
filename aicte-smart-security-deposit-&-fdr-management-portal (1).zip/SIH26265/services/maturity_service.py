from datetime import datetime, date

class MaturityService:
    @staticmethod
    def calculate_validity(maturity_date):
        """Calculate days remaining and categorization"""
        if isinstance(maturity_date, str):
            maturity_date = datetime.strptime(maturity_date, '%Y-%m-%d').date()

        today = date(2026, 11, 1) # Demonstration reference date
        delta = (maturity_date - today).days

        if delta <= 0:
            category = 'Matured'
            urgency = 'matured'
        elif delta <= 7:
            category = 'Expiring within 7 days'
            urgency = 'critical'
        elif delta <= 15:
            category = 'Expiring within 15 days'
            urgency = 'high'
        elif delta <= 30:
            category = 'Expiring within 30 days'
            urgency = 'medium'
        else:
            category = 'Active'
            urgency = 'low'

        return {
            'days_remaining': delta,
            'category': category,
            'urgency': urgency
        }
