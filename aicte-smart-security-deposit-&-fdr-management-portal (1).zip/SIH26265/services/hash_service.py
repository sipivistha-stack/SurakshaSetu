import hashlib
from models import FDRRecord

class HashService:
    @staticmethod
    def calculate_sha256(file_path):
        """Calculate SHA-256 hash of a file for anti-tamper and duplicate detection"""
        sha256_hash = hashlib.sha256()
        try:
            with open(file_path, "rb") as f:
                for byte_block in iter(lambda: f.read(4096), b""):
                    sha256_hash.update(byte_block)
            return sha256_hash.hexdigest()
        except Exception:
            return hashlib.sha256(file_path.encode()).hexdigest()

    @staticmethod
    def check_duplicate(fdr_number, bank_name, doc_hash, current_id=None):
        """Check duplicate FDR number or document hash"""
        query = FDRRecord.query
        if current_id:
            query = query.filter(FDRRecord.id != current_id)
            
        # Check FDR Number
        dup_number = query.filter_by(fdr_number=fdr_number.strip()).first()
        if dup_number:
            return True, f"FDR Number '{fdr_number}' already registered in system."
            
        # Check Document Hash
        if doc_hash:
            dup_doc = query.filter_by(document_hash=doc_hash).first()
            if dup_doc:
                return True, f"Identical document already submitted for FDR '{dup_doc.fdr_number}'."

        return False, None
