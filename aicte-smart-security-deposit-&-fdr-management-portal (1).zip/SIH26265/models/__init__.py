from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

db = SQLAlchemy()

class User(UserMixin, db.Model):
    __tablename__ = 'users'

    id = db.Column(db.String(36), primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(20), nullable=False) # 'ADMIN', 'OFFICER', 'INSTITUTION'
    designation = db.Column(db.String(150), nullable=False)
    region = db.Column(db.String(50), nullable=True) # For Regional Officers
    institution_id = db.Column(db.String(36), db.ForeignKey('institutions.id'), nullable=True)
    phone = db.Column(db.String(20), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'email': self.email,
            'role': self.role,
            'designation': self.designation,
            'region': self.region,
            'institutionId': self.institution_id,
            'phone': self.phone
        }

class Institution(db.Model):
    __tablename__ = 'institutions'

    id = db.Column(db.String(36), primary_key=True)
    aicte_permanent_id = db.Column(db.String(50), unique=True, nullable=False, index=True)
    name = db.Column(db.String(200), nullable=False)
    type = db.Column(db.String(50), nullable=False) # 'Engineering', 'Management', etc.
    region = db.Column(db.String(50), nullable=False, index=True)
    state = db.Column(db.String(100), nullable=False)
    city = db.Column(db.String(100), nullable=False)
    address = db.Column(db.Text, nullable=False)
    pincode = db.Column(db.String(10), nullable=False)
    contact_person = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    status = db.Column(db.String(30), default='Active') # 'Active', 'Under Review'
    established_year = db.Column(db.Integer, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    fdrs = db.relationship('FDRRecord', backref='institution', lazy=True)
    users = db.relationship('User', backref='institution', lazy=True)

    def to_dict(self):
        return {
            'id': self.id,
            'aictePermanentId': self.aicte_permanent_id,
            'name': self.name,
            'type': self.type,
            'region': self.region,
            'state': self.state,
            'city': self.city,
            'address': self.address,
            'pincode': self.pincode,
            'contactPerson': self.contact_person,
            'email': self.email,
            'phone': self.phone,
            'status': self.status,
            'establishedYear': self.established_year
        }

class FDRRecord(db.Model):
    __tablename__ = 'fdr_records'

    id = db.Column(db.String(36), primary_key=True)
    fdr_number = db.Column(db.String(100), unique=True, nullable=False, index=True)
    institution_id = db.Column(db.String(36), db.ForeignKey('institutions.id'), nullable=False, index=True)
    bank_name = db.Column(db.String(150), nullable=False, index=True)
    branch = db.Column(db.String(150), nullable=False)
    ifsc_code = db.Column(db.String(20), nullable=False)
    account_number = db.Column(db.String(50), nullable=True)
    deposit_amount = db.Column(db.Float, nullable=False)
    issue_date = db.Column(db.Date, nullable=False)
    maturity_date = db.Column(db.Date, nullable=False, index=True)
    interest_rate = db.Column(db.Float, default=7.0)
    beneficiary = db.Column(db.String(200), nullable=False)
    lien_marked = db.Column(db.Boolean, default=True)
    lien_details = db.Column(db.Text, nullable=True)
    
    # Statuses
    verification_status = db.Column(db.String(30), default='Pending', index=True) # Pending, Verified, Discrepancy, Query Raised, Rejected
    lifecycle_status = db.Column(db.String(30), default='Submitted', index=True) # Submitted, Active, Expiring Soon, Matured, Renewal Pending, Released
    
    # Document storage & audit
    document_name = db.Column(db.String(255), nullable=True)
    document_hash = db.Column(db.String(64), nullable=True, index=True) # SHA-256
    ocr_confidence = db.Column(db.Float, nullable=True)
    officer_remarks = db.Column(db.Text, nullable=True)
    query_message = db.Column(db.Text, nullable=True)
    query_response = db.Column(db.Text, nullable=True)
    linked_renewal_id = db.Column(db.String(36), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'fdrNumber': self.fdr_number,
            'institutionId': self.institution_id,
            'institutionName': self.institution.name if self.institution else '',
            'aictePermanentId': self.institution.aicte_permanent_id if self.institution else '',
            'region': self.institution.region if self.institution else '',
            'bankName': self.bank_name,
            'branch': self.branch,
            'ifscCode': self.ifsc_code,
            'accountNumber': self.account_number,
            'depositAmount': self.deposit_amount,
            'issueDate': self.issue_date.isoformat() if self.issue_date else '',
            'maturityDate': self.maturity_date.isoformat() if self.maturity_date else '',
            'interestRate': self.interest_rate,
            'beneficiary': self.beneficiary,
            'lienMarked': self.lien_marked,
            'lienDetails': self.lien_details,
            'verificationStatus': self.verification_status,
            'lifecycleStatus': self.lifecycle_status,
            'documentName': self.document_name,
            'documentHash': self.document_hash,
            'ocrConfidence': self.ocr_confidence,
            'officerRemarks': self.officer_remarks,
            'queryMessage': self.query_message,
            'queryResponse': self.query_response,
            'createdAt': self.created_at.isoformat() if self.created_at else ''
        }

class Renewal(db.Model):
    __tablename__ = 'renewals'

    id = db.Column(db.String(36), primary_key=True)
    old_fdr_id = db.Column(db.String(36), db.ForeignKey('fdr_records.id'), nullable=False)
    old_fdr_number = db.Column(db.String(100), nullable=False)
    new_fdr_number = db.Column(db.String(100), nullable=False)
    institution_id = db.Column(db.String(36), db.ForeignKey('institutions.id'), nullable=False)
    bank_name = db.Column(db.String(150), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    old_maturity_date = db.Column(db.Date, nullable=False)
    new_maturity_date = db.Column(db.Date, nullable=False)
    renewal_date = db.Column(db.Date, nullable=False)
    document_name = db.Column(db.String(255), nullable=True)
    document_hash = db.Column(db.String(64), nullable=True)
    status = db.Column(db.String(30), default='Pending Review')
    officer_remarks = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'oldFdrId': self.old_fdr_id,
            'oldFdrNumber': self.old_fdr_number,
            'newFdrNumber': self.new_fdr_number,
            'institutionId': self.institution_id,
            'bankName': self.bank_name,
            'amount': self.amount,
            'oldMaturityDate': self.old_maturity_date.isoformat() if self.old_maturity_date else '',
            'newMaturityDate': self.new_maturity_date.isoformat() if self.new_maturity_date else '',
            'renewalDate': self.renewal_date.isoformat() if self.renewal_date else '',
            'documentName': self.document_name,
            'status': self.status,
            'officerRemarks': self.officer_remarks
        }

class ReleaseRequest(db.Model):
    __tablename__ = 'release_requests'

    id = db.Column(db.String(36), primary_key=True)
    fdr_id = db.Column(db.String(36), db.ForeignKey('fdr_records.id'), nullable=False)
    fdr_number = db.Column(db.String(100), nullable=False)
    institution_id = db.Column(db.String(36), db.ForeignKey('institutions.id'), nullable=False)
    deposit_amount = db.Column(db.Float, nullable=False)
    reason = db.Column(db.String(100), nullable=False)
    closure_order_number = db.Column(db.String(100), nullable=False)
    
    # 4-Point Clearance Checklist
    tenure_completed = db.Column(db.Boolean, default=False)
    zero_dues_certificate = db.Column(db.Boolean, default=False)
    state_govt_noc = db.Column(db.Boolean, default=False)
    aicte_ec_approval = db.Column(db.Boolean, default=False)
    
    supporting_doc_name = db.Column(db.String(255), nullable=True)
    status = db.Column(db.String(30), default='Submitted') # Submitted, Under Scrutiny, Recommended, Approved, Rejected
    officer_remarks = db.Column(db.Text, nullable=True)
    approval_ref_no = db.Column(db.String(100), nullable=True)
    submitted_at = db.Column(db.DateTime, default=datetime.utcnow)
    reviewed_at = db.Column(db.DateTime, nullable=True)

    def to_dict(self):
        return {
            'id': self.id,
            'fdrId': self.fdr_id,
            'fdrNumber': self.fdr_number,
            'institutionId': self.institution_id,
            'depositAmount': self.deposit_amount,
            'reason': self.reason,
            'closureOrderNumber': self.closure_order_number,
            'checklist': {
                'tenureCompleted': self.tenure_completed,
                'zeroDuesCertificate': self.zero_dues_certificate,
                'stateGovtNoc': self.state_govt_noc,
                'aicteEcApproval': self.aicte_ec_approval
            },
            'supportingDocName': self.supporting_doc_name,
            'status': self.status,
            'officerRemarks': self.officer_remarks,
            'approvalReferenceNo': self.approval_ref_no,
            'submittedAt': self.submitted_at.isoformat() if self.submitted_at else ''
        }

class Notification(db.Model):
    __tablename__ = 'notifications'

    id = db.Column(db.String(36), primary_key=True)
    recipient_role = db.Column(db.String(20), nullable=True)
    recipient_institution_id = db.Column(db.String(36), nullable=True)
    title = db.Column(db.String(200), nullable=False)
    message = db.Column(db.Text, nullable=False)
    type = db.Column(db.String(20), default='info')
    read = db.Column(db.Boolean, default=False)
    link_action = db.Column(db.String(50), nullable=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'recipientRole': self.recipient_role,
            'recipientInstitutionId': self.recipient_institution_id,
            'title': self.title,
            'message': self.message,
            'type': self.type,
            'read': self.read,
            'linkAction': self.link_action,
            'timestamp': self.timestamp.isoformat() if self.timestamp else ''
        }

class AuditLog(db.Model):
    __tablename__ = 'audit_logs'

    id = db.Column(db.String(36), primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    user_id = db.Column(db.String(36), nullable=False)
    user_name = db.Column(db.String(120), nullable=False)
    user_role = db.Column(db.String(20), nullable=False)
    action = db.Column(db.String(100), nullable=False)
    module = db.Column(db.String(100), nullable=False)
    details = db.Column(db.Text, nullable=False)
    ip_address = db.Column(db.String(50), nullable=False)
    checksum = db.Column(db.String(64), nullable=False) # SHA-256 anti-tamper hash

    def to_dict(self):
        return {
            'id': self.id,
            'timestamp': self.timestamp.isoformat() if self.timestamp else '',
            'userId': self.user_id,
            'userName': self.user_name,
            'userRole': self.user_role,
            'action': self.action,
            'module': self.module,
            'details': self.details,
            'ipAddress': self.ip_address,
            'checksum': self.checksum
        }
