import os
from flask import Flask, jsonify, request, session
from flask_cors import CORS
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from datetime import datetime

from config import Config
from models import db, User, Institution, FDRRecord, Renewal, ReleaseRequest, Notification, AuditLog
from services.ocr_service import OCRService
from services.hash_service import HashService
from services.maturity_service import MaturityService

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # Initialize extensions
    db.init_app(app)
    CORS(app, supports_credentials=True)

    login_manager = LoginManager()
    login_manager.init_app(app)

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(user_id)

    # Ensure uploads & database folders exist
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    os.makedirs(os.path.dirname(app.config['SQLALCHEMY_DATABASE_URI'].replace('sqlite:///', '')), exist_ok=True)

    # Helper: Log audit
    def log_audit(action, module, details, user_id=None, user_name=None, user_role=None):
        uid = user_id or (current_user.id if current_user.is_authenticated else 'system')
        uname = user_name or (current_user.name if current_user.is_authenticated else 'System')
        urole = user_role or (current_user.role if current_user.is_authenticated else 'SYSTEM')
        log = AuditLog(
            id=f"log-{int(datetime.utcnow().timestamp()*1000)}",
            user_id=uid,
            user_name=uname,
            user_role=urole,
            action=action,
            module=module,
            details=details,
            ip_address=request.remote_addr or '127.0.0.1',
            checksum=HashService.calculate_sha256(f"{action}-{details}-{datetime.utcnow().isoformat()}")
        )
        db.session.add(log)
        db.session.commit()

    # ------------------ REST APIS ------------------ #

    # 1. AUTHENTICATION
    @app.route('/api/auth/login', methods=['POST'])
    def login():
        data = request.get_json() or {}
        email = data.get('email', '').strip()
        password = data.get('password', '').strip()

        user = User.query.filter_by(email=email).first()
        if user and user.check_password(password):
            login_user(user)
            log_audit('USER_LOGIN', 'Authentication', f"User {user.email} authenticated successfully")
            return jsonify({'success': True, 'user': user.to_dict()}), 200

        return jsonify({'success': False, 'message': 'Invalid credentials'}), 401

    @app.route('/api/auth/logout', methods=['POST'])
    def logout():
        logout_user()
        return jsonify({'success': True, 'message': 'Logged out successfully'}), 200

    @app.route('/api/auth/me', methods=['GET'])
    def me():
        if current_user.is_authenticated:
            return jsonify({'authenticated': True, 'user': current_user.to_dict()}), 200
        return jsonify({'authenticated': False}), 200

    # 2. INSTITUTIONS
    @app.route('/api/institutions', methods=['GET'])
    def get_institutions():
        insts = Institution.query.all()
        return jsonify([i.to_dict() for i in insts]), 200

    @app.route('/api/institutions/<id>', methods=['GET'])
    def get_institution(id):
        inst = Institution.query.get_or_404(id)
        return jsonify(inst.to_dict()), 200

    # 3. FDR MANAGEMENT
    @app.route('/api/fdrs', methods=['GET'])
    def get_fdrs():
        query = FDRRecord.query
        region = request.args.get('region')
        status = request.args.get('status')
        institution_id = request.args.get('institutionId')

        if region:
            query = query.join(Institution).filter(Institution.region == region)
        if status:
            query = query.filter((FDRRecord.verification_status == status) | (FDRRecord.lifecycle_status == status))
        if institution_id:
            query = query.filter_by(institution_id=institution_id)

        records = query.all()
        return jsonify([f.to_dict() for f in records]), 200

    @app.route('/api/fdrs', methods=['POST'])
    def create_fdr():
        data = request.get_json() or {}
        fdr_num = data.get('fdrNumber')
        bank = data.get('bankName')
        doc_hash = data.get('documentHash', '')

        # Duplicate check
        is_dup, reason = HashService.check_duplicate(fdr_num, bank, doc_hash)
        if is_dup:
            return jsonify({'success': False, 'message': reason}), 400

        new_fdr = FDRRecord(
            id=f"fdr-{int(datetime.utcnow().timestamp()*1000)}",
            fdr_number=fdr_num,
            institution_id=data.get('institutionId'),
            bank_name=bank,
            branch=data.get('branch'),
            ifsc_code=data.get('ifscCode'),
            account_number=data.get('accountNumber'),
            deposit_amount=float(data.get('depositAmount', 0)),
            issue_date=datetime.strptime(data.get('issueDate'), '%Y-%m-%d').date(),
            maturity_date=datetime.strptime(data.get('maturityDate'), '%Y-%m-%d').date(),
            interest_rate=float(data.get('interestRate', 7.0)),
            beneficiary=data.get('beneficiary', 'Member Secretary, AICTE'),
            lien_marked=data.get('lienMarked', True),
            lien_details=data.get('lienDetails', ''),
            verification_status='Pending',
            lifecycle_status='Submitted',
            document_name=data.get('documentName'),
            document_hash=doc_hash,
            ocr_confidence=data.get('ocrConfidence', 95.0)
        )
        db.session.add(new_fdr)
        db.session.commit()
        log_audit('FDR_CREATED', 'FDR Management', f"Created FDR {fdr_num}")
        return jsonify({'success': True, 'fdr': new_fdr.to_dict()}), 201

    @app.route('/api/fdrs/<id>', methods=['GET'])
    def get_fdr(id):
        fdr = FDRRecord.query.get_or_404(id)
        return jsonify(fdr.to_dict()), 200

    @app.route('/api/fdrs/statistics', methods=['GET'])
    def get_fdr_statistics():
        total_fdrs = FDRRecord.query.count()
        total_insts = Institution.query.count()
        records = FDRRecord.query.all()
        total_vault = sum(f.deposit_amount for f in records)
        pending = sum(1 for f in records if f.verification_status in ['Pending', 'Discrepancy'])
        active = sum(1 for f in records if f.lifecycle_status == 'Active')
        expiring = sum(1 for f in records if f.lifecycle_status == 'Expiring Soon')
        matured = sum(1 for f in records if f.lifecycle_status == 'Matured')

        return jsonify({
            'totalInstitutions': total_insts,
            'totalFdrs': total_fdrs,
            'totalDepositValue': total_vault,
            'pendingVerifications': pending,
            'activeFdrs': active,
            'expiringFdrs': expiring,
            'maturedFdrs': matured
        }), 200

    # 4. VERIFICATION & OCR
    @app.route('/api/verification/pending', methods=['GET'])
    def get_pending_verification():
        pending = FDRRecord.query.filter(FDRRecord.verification_status.in_(['Pending', 'Discrepancy', 'Query Raised'])).all()
        return jsonify([p.to_dict() for p in pending]), 200

    @app.route('/api/verification/<id>/approve', methods=['POST'])
    def approve_verification(id):
        fdr = FDRRecord.query.get_or_404(id)
        data = request.get_json() or {}
        fdr.verification_status = 'Verified'
        fdr.lifecycle_status = 'Active'
        fdr.officer_remarks = data.get('remarks', 'Approved by Regional Officer.')
        db.session.commit()
        log_audit('VERIFY_APPROVE', 'Verification', f"FDR {fdr.fdr_number} verified and approved")
        return jsonify({'success': True, 'fdr': fdr.to_dict()}), 200

    @app.route('/api/verification/<id>/reject', methods=['POST'])
    def reject_verification(id):
        fdr = FDRRecord.query.get_or_404(id)
        data = request.get_json() or {}
        fdr.verification_status = 'Rejected'
        fdr.officer_remarks = data.get('remarks', 'Rejected due to statutory non-compliance.')
        db.session.commit()
        log_audit('VERIFY_REJECT', 'Verification', f"FDR {fdr.fdr_number} rejected")
        return jsonify({'success': True, 'fdr': fdr.to_dict()}), 200

    @app.route('/api/verification/<id>/query', methods=['POST'])
    def query_verification(id):
        fdr = FDRRecord.query.get_or_404(id)
        data = request.get_json() or {}
        fdr.verification_status = 'Query Raised'
        fdr.query_message = data.get('queryMessage')
        db.session.commit()
        log_audit('VERIFY_QUERY', 'Verification', f"Query issued for FDR {fdr.fdr_number}")
        return jsonify({'success': True, 'fdr': fdr.to_dict()}), 200

    # 5. RENEWALS
    @app.route('/api/renewals', methods=['GET'])
    def get_renewals():
        rnws = Renewal.query.all()
        return jsonify([r.to_dict() for r in rnws]), 200

    @app.route('/api/renewals/<id>/approve', methods=['POST'])
    def approve_renewal(id):
        rnw = Renewal.query.get_or_404(id)
        rnw.status = 'Approved'
        old_fdr = FDRRecord.query.get(rnw.old_fdr_id)
        if old_fdr:
            old_fdr.lifecycle_status = 'Matured'
            old_fdr.officer_remarks = f"Renewed into FDR {rnw.new_fdr_number}"
        db.session.commit()
        log_audit('RENEWAL_APPROVED', 'Renewals', f"Approved replacement FDR {rnw.new_fdr_number}")
        return jsonify({'success': True, 'renewal': rnw.to_dict()}), 200

    # 6. RELEASES
    @app.route('/api/releases', methods=['GET'])
    def get_releases():
        rels = ReleaseRequest.query.all()
        return jsonify([r.to_dict() for r in rels]), 200

    @app.route('/api/releases/<id>/approve', methods=['POST'])
    def approve_release(id):
        rel = ReleaseRequest.query.get_or_404(id)
        rel.status = 'Approved'
        fdr = FDRRecord.query.get(rel.fdr_id)
        if fdr:
            fdr.lifecycle_status = 'Released'
        db.session.commit()
        log_audit('RELEASE_APPROVED', 'Release Management', f"Executive sanction granted for FDR {rel.fdr_number}")
        return jsonify({'success': True, 'release': rel.to_dict()}), 200

    # 7. AUDIT LOGS
    @app.route('/api/audit-logs', methods=['GET'])
    def get_audit_logs():
        logs = AuditLog.query.order_by(AuditLog.timestamp.desc()).limit(100).all()
        return jsonify([l.to_dict() for l in logs]), 200

    return app

if __name__ == '__main__':
    app = create_app()
    with app.app_context():
        db.create_all()
    app.run(host='0.0.0.0', port=5000, debug=True)
