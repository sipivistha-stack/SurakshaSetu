import pytest
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app import create_app
from models import db, User, Institution, FDRRecord
from services.maturity_service import MaturityService
from services.hash_service import HashService

@pytest.fixture
def client():
    app = create_app()
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    
    with app.test_client() as client:
        with app.app_context():
            db.create_all()
            yield client
            db.drop_all()

def test_maturity_calculation():
    # Test remaining validity days categorization
    res_critical = MaturityService.calculate_validity('2026-11-05')
    assert res_critical['urgency'] == 'critical'
    
    res_matured = MaturityService.calculate_validity('2026-10-15')
    assert res_matured['category'] == 'Matured'

def test_duplicate_hash_calculation():
    hash1 = HashService.calculate_sha256('sample-document-text')
    assert len(hash1) == 64
