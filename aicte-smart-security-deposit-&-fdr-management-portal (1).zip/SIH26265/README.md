# Smart India Hackathon (SIH26265)
## AICTE Smart Security Deposit & FDR Management Portal

A centralized digital platform automating the Fixed Deposit Receipt (FDR) and security deposit lifecycle for the **All India Council for Technical Education (AICTE)**, Ministry of Education, Government of India.

---

### 1. Key Problem Addressed
- Manual paper slip tracking across thousands of technical institutions
- High risk of forged or altered certificates, smudged seals, or missing AICTE joint lien clauses
- Premature liquidation without AICTE statutory knowledge
- Missed maturity dates leading to compliance slippage and loss of institutional interest
- Tedious deposit release scrutiny without verified multi-agency clearance certificates

---

### 2. Dual-Engine Architecture
1. **Interactive Live Enterprise Portal (Dev Server Port 3000)**:
   - Full role-based workflows for **AICTE Admin**, **Regional Officers**, and **Technical Institutions**.
   - Interactive OCR Inspection Desk with visual side-by-side certificate preview, bounding highlights, and color-coded discrepancy diffs (Green matched, Red mismatch, Yellow missing).
   - Dynamic maturity countdown engine and automated notification center.
   - 4-point statutory release scrutiny workflow and CSV exports.

2. **Standalone Python Flask + SQLite Backend (`SIH26265/`)**:
   - Built strictly using **Python Flask**, **Flask-SQLAlchemy**, **Flask-Login**, **PyMuPDF**, and **Tesseract OCR**.
   - RESTful API endpoints for authentication, institutions, FDRs, verification, renewals, and releases.
   - SHA-256 anti-tamper duplicate document detection.

---

### 3. User Roles & Access Control
- **AICTE Admin (`admin@aicte.gov.in`)**:
  - Global vault monitoring (total deposits across India, regional distribution, bank concentration).
  - Executive sign-off on release dossiers and system audit trail inspection.
- **Regional / Verification Officer (`ro.west@aicte.gov.in`, `ro.north@aicte.gov.in`)**:
  - Regional jurisdiction queue (Western Region / Northern Region).
  - OCR verification desk with field diffing, approve/reject/raise query actions.
  - 4-point release scrutiny checklist (Tenure, Zero Dues, State NOC, AICTE EC Approval).
- **Technical Institution (`principal@vjti.ac.in`, `director@coep.ac.in`)**:
  - Multi-step FDR lodging wizard with instant pre-submission OCR discrepancy check.
  - Query response desk for officer deficiency notices.
  - Rollover renewal application and release claims.

---

### 4. Running the Standalone Python Flask Backend
```bash
# 1. Open project directory
cd SIH26265

# 2. Install dependencies
pip install -r requirements.txt

# 3. Seed database with hackathon sample dataset
python database/seed_data.py

# 4. Start Flask REST API server
python app.py
```

---

### 5. Running the Automated Unit Tests
```bash
pytest tests/test_fdr.py
```
