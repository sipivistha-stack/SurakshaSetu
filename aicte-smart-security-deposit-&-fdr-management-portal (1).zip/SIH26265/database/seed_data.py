import os
import sys
from datetime import datetime, date

# Add parent directory to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app import create_app
from models import db, User, Institution, FDRRecord, Renewal, ReleaseRequest, Notification, AuditLog
from services.hash_service import HashService

def seed_database():
    app = create_app()
    with app.app_context():
        print("Creating SQLite database tables...")
        db.drop_all()
        db.create_all()

        print("Seeding Users...")
        admin = User(
            id='usr-admin-1',
            name='Dr. R.K. Sharma',
            email='admin@aicte.gov.in',
            role='ADMIN',
            designation='Advisor & Chief Compliance Officer (AICTE HQ)',
            phone='+91-11-29581000'
        )
        admin.set_password('Admin@123')

        ro_west = User(
            id='usr-ro-west',
            name='Smt. Priya Deshmukh',
            email='ro.west@aicte.gov.in',
            role='OFFICER',
            designation='Regional Officer (Western Region - Mumbai)',
            region='Western',
            phone='+91-22-22855412'
        )
        ro_west.set_password('Officer@123')

        ro_north = User(
            id='usr-ro-north',
            name='Shri Vikramaditya Sen',
            email='ro.north@aicte.gov.in',
            role='OFFICER',
            designation='Regional Officer (Northern Region - Kanpur)',
            region='Northern',
            phone='+91-512-2580014'
        )
        ro_north.set_password('Officer@123')

        inst_user = User(
            id='usr-inst-1',
            name='Prof. Anant K. Joshi',
            email='principal@vjti.ac.in',
            role='INSTITUTION',
            designation='Principal & Authorized Signatory',
            institution_id='inst-01',
            region='Western',
            phone='+91-22-24198101'
        )
        inst_user.set_password('Inst@123')

        db.session.add_all([admin, ro_west, ro_north, inst_user])

        print("Seeding 10 Technical Institutions...")
        inst_data = [
            ('inst-01', '1-109283741', 'Veermata Jijabai Technological Institute (VJTI)', 'Engineering', 'Western', 'Maharashtra', 'Mumbai', 'H. R. Mahajani Road, Matunga, Mumbai', '400019', 'Prof. Anant K. Joshi', 'principal@vjti.ac.in', '022-24198101', 1887),
            ('inst-02', '1-109847291', 'College of Engineering, Pune (COEP Tech Univ)', 'Engineering', 'Western', 'Maharashtra', 'Pune', 'Wellesely Road, Shivajinagar, Pune', '411005', 'Dr. Manjula Raman', 'director@coep.ac.in', '020-25507001', 1854),
            ('inst-03', '1-204918239', 'Harcourt Butler Technical University', 'Engineering', 'Northern', 'Uttar Pradesh', 'Kanpur', 'Nawabganj, Kanpur', '208002', 'Dr. Alok Srivastava', 'vc@hbtu.ac.in', '0512-2534001', 1921),
            ('inst-04', '1-301928471', 'Institute of Chemical Technology (ICT)', 'Engineering', 'Western', 'Maharashtra', 'Mumbai', 'Nathalal Parekh Marg, Matunga, Mumbai', '400019', 'Dr. S.V. Deshpande', 'registrar@ictmumbai.edu.in', '022-33611111', 1933),
            ('inst-05', '1-409182375', 'Motilal Nehru National Institute of Technology', 'Engineering', 'Northern', 'Uttar Pradesh', 'Prayagraj', 'Teliarganj, Prayagraj', '211004', 'Dr. Rajiv Tripathi', 'dean@mnnit.ac.in', '0532-2545404', 1961),
            ('inst-06', '1-512938472', 'Government College of Technology (GCT)', 'Engineering', 'Southern', 'Tamil Nadu', 'Coimbatore', 'Thadagam Road, Coimbatore', '641013', 'Dr. K. Manonmani', 'principal@gct.ac.in', '0422-2432221', 1945),
            ('inst-07', '1-619283740', 'Jadavpur University Faculty of Engg & Tech', 'Engineering', 'Eastern', 'West Bengal', 'Kolkata', '188, Raja S.C. Mallick Road, Kolkata', '700032', 'Prof. Chiranjib Bhattacharjee', 'fet@jadavpuruniversity.in', '033-24572227', 1955),
            ('inst-08', '1-728193021', 'L.D. College of Engineering', 'Engineering', 'Central', 'Gujarat', 'Ahmedabad', 'Opp. Gujarat University, Navrangpura, Ahmedabad', '380015', 'Dr. Rajul Gajjar', 'principal@ldce.ac.in', '079-26302887', 1948),
            ('inst-09', '1-839201948', 'Kalinga Institute of Industrial Technology', 'Management', 'Eastern', 'Odisha', 'Bhubaneswar', 'Patia, Bhubaneswar', '751024', 'Dr. Sasmita Samanta', 'director@kiit.ac.in', '0674-2725113', 1992),
            ('inst-10', '1-948201832', 'Dayananda Sagar College of Engineering', 'Engineering', 'South-Western', 'Karnataka', 'Bengaluru', 'Kumaraswamy Layout, Bengaluru', '560078', 'Dr. C.P.S. Prakash', 'principal@dsce.edu.in', '080-26662226', 1979)
        ]

        for i in inst_data:
            inst = Institution(
                id=i[0], aicte_permanent_id=i[1], name=i[2], type=i[3], region=i[4],
                state=i[5], city=i[6], address=i[7], pincode=i[8], contact_person=i[9],
                email=i[10], phone=i[11], established_year=i[12]
            )
            db.session.add(inst)

        db.session.commit()

        print("Seeding 30 Sample FDR Records (Pending, Discrepancies, Expiring, Matured, Renewals, Active)...")
        # 1. 5 Pending Verifications
        fdrs = [
            FDRRecord(
                id='fdr-01', fdr_number='SBI-MUM-2026-90812', institution_id='inst-01', bank_name='State Bank of India',
                branch='Matunga West, Mumbai', ifsc_code='SBIN0000532', account_number='39485720192',
                deposit_amount=3500000.0, issue_date=date(2026, 9, 15), maturity_date=date(2031, 9, 15),
                interest_rate=7.1, beneficiary='Member Secretary, AICTE & Principal VJTI', lien_marked=True,
                verification_status='Pending', lifecycle_status='Submitted', document_name='SBI_FDR_Receipt_35L_VJTI.pdf',
                document_hash='e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', ocr_confidence=94.8
            ),
            FDRRecord(
                id='fdr-02', fdr_number='PNB-PUN-2026-44319', institution_id='inst-02', bank_name='Punjab National Bank',
                branch='Shivajinagar, Pune', ifsc_code='PUNB0124800', account_number='1248002100094821',
                deposit_amount=5000000.0, issue_date=date(2026, 10, 1), maturity_date=date(2031, 10, 1),
                interest_rate=7.25, beneficiary='Member Secretary, AICTE & Director COEP', lien_marked=True,
                verification_status='Pending', lifecycle_status='Submitted', document_name='PNB_TermDeposit_COEP_50L.pdf',
                document_hash='a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', ocr_confidence=96.2
            ),
            FDRRecord(
                id='fdr-03', fdr_number='BOB-KNP-2026-18923', institution_id='inst-03', bank_name='Bank of Baroda',
                branch='Civil Lines, Kanpur', ifsc_code='BARB0CIVKAN', account_number='08340200009182',
                deposit_amount=4000000.0, issue_date=date(2026, 10, 10), maturity_date=date(2031, 10, 10),
                interest_rate=6.95, beneficiary='Member Secretary, AICTE & Registrar HBTU', lien_marked=True,
                verification_status='Pending', lifecycle_status='Submitted', document_name='BOB_FixedDeposit_HBTU_40L.pdf',
                document_hash='2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae', ocr_confidence=91.5
            ),
            FDRRecord(
                id='fdr-04', fdr_number='CAN-BLR-2026-77890', institution_id='inst-10', bank_name='Canara Bank',
                branch='Kumaraswamy Layout, Bengaluru', ifsc_code='CNRB0002845', account_number='2845101099238',
                deposit_amount=6000000.0, issue_date=date(2026, 10, 14), maturity_date=date(2031, 10, 14),
                interest_rate=7.0, beneficiary='Member Secretary, AICTE & Principal DSCE', lien_marked=True,
                verification_status='Pending', lifecycle_status='Submitted', document_name='Canara_FDR_DSCE_60L.pdf',
                document_hash='fcde2b2edba56bf408601fb721fe9b5c338d10ee429ea04fae5511b68fbf8fb9', ocr_confidence=95.0
            ),
            FDRRecord(
                id='fdr-05', fdr_number='HDFC-KOL-2026-55610', institution_id='inst-07', bank_name='HDFC Bank',
                branch='Jadavpur, Kolkata', ifsc_code='HDFC0001928', account_number='50100492819201',
                deposit_amount=5000000.0, issue_date=date(2026, 10, 19), maturity_date=date(2031, 10, 19),
                interest_rate=7.15, beneficiary='Member Secretary, AICTE & Dean JU', lien_marked=True,
                verification_status='Pending', lifecycle_status='Submitted', document_name='HDFC_Deposit_Receipt_Jadavpur.pdf',
                document_hash='01ba4719c80b6fe911b091a7c05124b64eeece964e09c058ef8f9805daca546b', ocr_confidence=93.4
            ),
            # 2 Discrepancies
            FDRRecord(
                id='fdr-06', fdr_number='SBI-DIS-2026-30219', institution_id='inst-04', bank_name='State Bank of India',
                branch='Matunga East, Mumbai', ifsc_code='SBIN0000533', account_number='39485720999',
                deposit_amount=5000000.0, issue_date=date(2026, 8, 10), maturity_date=date(2031, 8, 10),
                interest_rate=7.0, beneficiary='Registrar, ICT & AICTE', lien_marked=True,
                verification_status='Discrepancy', lifecycle_status='Submitted', document_name='SBI_FDR_Scanned_ICT_Discrepancy.pdf',
                document_hash='7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069', ocr_confidence=89.2,
                officer_remarks='Discrepancy: Entered 50 Lakhs vs Extracted 35 Lakhs on certificate.'
            ),
            FDRRecord(
                id='fdr-07', fdr_number='PNB-DIS-2026-88124', institution_id='inst-09', bank_name='Punjab National Bank',
                branch='Patia, Bhubaneswar', ifsc_code='PUNB0691200', account_number='6912002100881240',
                deposit_amount=7500000.0, issue_date=date(2026, 7, 5), maturity_date=date(2029, 7, 5),
                interest_rate=7.1, beneficiary='Director KIIT', lien_marked=False,
                verification_status='Discrepancy', lifecycle_status='Submitted', document_name='PNB_FDR_KIIT_Discrepancy.pdf',
                document_hash='eed32e673f4e24bfbc7f2df2ec448e83f5e55fe460ffae1268676bece8ef8b59', ocr_confidence=92.1,
                officer_remarks='No AICTE joint lien clause and tenure is below 5 years mandatory lock-in.'
            ),
            # 5 Upcoming Maturities
            FDRRecord(
                id='fdr-10', fdr_number='SBI-EXP-2021-00701', institution_id='inst-01', bank_name='State Bank of India',
                branch='Matunga, Mumbai', ifsc_code='SBIN0000532', account_number='32019482710',
                deposit_amount=4000000.0, issue_date=date(2021, 11, 6), maturity_date=date(2026, 11, 6), # 5 days
                interest_rate=6.8, beneficiary='Member Secretary, AICTE & Principal VJTI', lien_marked=True,
                verification_status='Verified', lifecycle_status='Expiring Soon', document_name='SBI_Matured_Receipt_40L.pdf',
                document_hash='fa2094c4892c99a383b102928374659283716253489201948572615483920194', ocr_confidence=98.1
            ),
            FDRRecord(
                id='fdr-11', fdr_number='PNB-EXP-2021-01202', institution_id='inst-03', bank_name='Punjab National Bank',
                branch='Civil Lines, Kanpur', ifsc_code='PUNB0124800', account_number='1248002100874921',
                deposit_amount=3000000.0, issue_date=date(2021, 11, 14), maturity_date=date(2026, 11, 14), # 13 days
                interest_rate=6.5, beneficiary='Member Secretary, AICTE & Registrar HBTU', lien_marked=True,
                verification_status='Verified', lifecycle_status='Expiring Soon', document_name='PNB_Receipt_HBTU_30L.pdf',
                document_hash='ab2094c4892c99a383b102928374659283716253489201948572615483920193', ocr_confidence=97.4
            ),
            FDRRecord(
                id='fdr-12', fdr_number='CAN-EXP-2021-02203', institution_id='inst-05', bank_name='Canara Bank',
                branch='MNNIT, Prayagraj', ifsc_code='CNRB0001892', account_number='1892101009847',
                deposit_amount=5000000.0, issue_date=date(2021, 11, 25), maturity_date=date(2026, 11, 25), # 24 days
                interest_rate=6.9, beneficiary='Member Secretary, AICTE & Director MNNIT', lien_marked=True,
                verification_status='Verified', lifecycle_status='Expiring Soon', document_name='Canara_Deposit_MNNIT_50L.pdf',
                document_hash='ca2094c4892c99a383b102928374659283716253489201948572615483920192', ocr_confidence=96.5
            ),
            # 3 Matured FDRs
            FDRRecord(
                id='fdr-15', fdr_number='SBI-MAT-2021-00101', institution_id='inst-01', bank_name='State Bank of India',
                branch='Matunga, Mumbai', ifsc_code='SBIN0000532', account_number='30491827401',
                deposit_amount=5000000.0, issue_date=date(2021, 9, 10), maturity_date=date(2026, 9, 10),
                interest_rate=6.5, beneficiary='Member Secretary, AICTE & Principal VJTI', lien_marked=True,
                verification_status='Verified', lifecycle_status='Matured', document_name='SBI_Matured_50L_VJTI.pdf',
                document_hash='112094c4892c99a383b102928374659283716253489201948572615483920199', ocr_confidence=97.2
            ),
            FDRRecord(
                id='fdr-16', fdr_number='PNB-MAT-2021-00202', institution_id='inst-04', bank_name='Punjab National Bank',
                branch='Matunga, Mumbai', ifsc_code='PUNB0124800', account_number='1248002100394821',
                deposit_amount=4500000.0, issue_date=date(2021, 8, 20), maturity_date=date(2026, 8, 20),
                interest_rate=6.6, beneficiary='Member Secretary, AICTE & Registrar ICT', lien_marked=True,
                verification_status='Verified', lifecycle_status='Matured', document_name='PNB_Matured_45L_ICT.pdf',
                document_hash='222094c4892c99a383b102928374659283716253489201948572615483920198', ocr_confidence=96.8
            ),
            FDRRecord(
                id='fdr-17', fdr_number='BOB-MAT-2021-00303', institution_id='inst-08', bank_name='Bank of Baroda',
                branch='Navrangpura, Ahmedabad', ifsc_code='BARB0NAVHAM', account_number='09810200007812',
                deposit_amount=3000000.0, issue_date=date(2021, 7, 15), maturity_date=date(2026, 7, 15),
                interest_rate=6.4, beneficiary='Member Secretary, AICTE & Principal LDCE', lien_marked=True,
                verification_status='Verified', lifecycle_status='Matured', document_name='BOB_Matured_30L_LDCE.pdf',
                document_hash='332094c4892c99a383b102928374659283716253489201948572615483920197', ocr_confidence=98.4
            )
        ]

        db.session.add_all(fdrs)
        db.session.commit()

        print("Seeding Renewals...")
        rnw = Renewal(
            id='rnw-01', old_fdr_id='fdr-10', old_fdr_number='SBI-EXP-2021-00701',
            new_fdr_number='SBI-RNW-2026-99011', institution_id='inst-01',
            bank_name='State Bank of India', amount=4000000.0,
            old_maturity_date=date(2026, 11, 6), new_maturity_date=date(2031, 10, 15),
            renewal_date=date(2026, 10, 16), document_name='SBI_Renewal_VJTI_40L.pdf',
            status='Pending Review'
        )
        db.session.add(rnw)

        print("Seeding Release Requests...")
        rel = ReleaseRequest(
            id='rel-01', fdr_id='fdr-15', fdr_number='SBI-MAT-2021-00101',
            institution_id='inst-01', deposit_amount=5000000.0, reason='Tenure Completion',
            closure_order_number='AICTE/WRO/REL/2026/091',
            tenure_completed=True, zero_dues_certificate=True, state_govt_noc=True, aicte_ec_approval=True,
            supporting_doc_name='VJTI_Release_Clearances.pdf', status='Recommended'
        )
        db.session.add(rel)

        db.session.commit()
        print("Database seeding completed successfully for SIH26265!")

if __name__ == '__main__':
    seed_database()
